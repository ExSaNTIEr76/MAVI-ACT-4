//SANTIAGO EXEQUIEL FERN�NDEZ - MAVI ACT. 4:

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

Texture texture;
Sprite sprite;

int main() {

    texture.loadFromFile("crosshair.png");
    sprite.setTexture(texture);

    sprite.setPosition(350, 250);

    sf::RenderWindow App(sf::VideoMode(800, 600), "Crosshair");

    while (App.isOpen()) {
        sf::Event event;
        while (App.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                App.close();
        }

        App.clear();

       
        App.draw(sprite);

        App.display();
    }

    return 0;
}