//SANTIAGO EXEQUIEL FERN�NDEZ - MAVI ACT. 4:

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

Texture texture1;
Texture texture2;

Sprite shapeSprite;

int main() {
    texture1.loadFromFile("cuad_yellow.png");
    texture2.loadFromFile("rcircleg.png");

    shapeSprite.setTexture(texture1);

    Vector2f shapePosition(400, 300);
    Vector2u windowSize(800, 600);

    float shapeSize = 50.0f;
    float texture1Size = 128.0f;
    float texture2Size = 512.0f;

    RenderWindow App(VideoMode(800, 600), "Atrapado");

    bool isCircle = false;

    while (App.isOpen()) {
        Event event;
        while (App.pollEvent(event)) {
            if (event.type == Event::Closed) {
                App.close();
            }
        }

        if (Keyboard::isKeyPressed(Keyboard::Space) && !isCircle) {
            isCircle = true;
            shapeSprite.setTexture(texture2);
            shapeSize = (shapeSize / texture1Size) * texture2Size;
        }

        if (Keyboard::isKeyPressed(Keyboard::Left) && shapePosition.x > 0) {
            shapePosition.x -= 0.1;
        }
        if (Keyboard::isKeyPressed(Keyboard::Right) && shapePosition.x + shapeSize < windowSize.x) {
            shapePosition.x += 0.1;
        }
        if (Keyboard::isKeyPressed(Keyboard::Up) && shapePosition.y > 0) {
            shapePosition.y -= 0.1;
        }
        if (Keyboard::isKeyPressed(Keyboard::Down) && shapePosition.y + shapeSize < windowSize.y) {
            shapePosition.y += 0.1;
        }

        shapeSprite.setPosition(shapePosition);
        shapeSprite.setScale(shapeSize / texture2Size, shapeSize / texture2Size);

        App.clear();
        App.draw(shapeSprite);
        App.display();
    }

    return 0;
}