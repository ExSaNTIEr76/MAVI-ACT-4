//SANTIAGO EXEQUIEL FERN�NDEZ - MAVI ACT. 4:

#pragma once

#include "stdafx.h"

using namespace sf;

class Enemigo {

	Texture _enemyTex;
	Sprite _enemySprite;
	bool _estaVivo;
	bool _estaVisible;
	sf::Clock _clock;
	float _tiempoVisible;
	float _tiempoApagado;

	Vector2f _randomPos(Vector2u maxPos) {

		Vector2f random((float)(rand() % maxPos.x), (float)(rand() % maxPos.y));
		return random;

	}

public:

	Enemigo() {

		_enemyTex.loadFromFile("et.png");
		_enemySprite.setTexture(_enemyTex);
		_enemySprite.setScale(0.15f, 0.15f);
		_estaVivo = true;
		_estaVisible = false;
		_tiempoVisible = 0.5f;
		_tiempoApagado = 0.5f;
	}

	bool EstaVivo() {
		return _estaVivo;
	}

	bool EstaActivo() {
		return _estaVivo && _estaVisible;
	}

	bool EstaEncima(float x, float y) {
		FloatRect bounds = _enemySprite.getGlobalBounds();
		return bounds.contains(x, y);
	}

	void Derrotar() {
		_estaVivo = false;
	}

	void Dibujar(RenderWindow* wnd) {
		wnd->draw(_enemySprite);
	}

	void Actualizar(RenderWindow* wnd) {
		if (!_estaVivo)
			return;

		if (!_estaVisible) {
			if (_clock.getElapsedTime().asSeconds() > _tiempoApagado) {
				_clock.restart();
				if (rand() % 100 < 25) {
					_estaVisible = true;
					_enemySprite.setPosition(_randomPos(wnd->getSize()));
				}
			}
		}
		else {
			if (_clock.getElapsedTime().asSeconds() > _tiempoVisible) {
				_estaVisible = false;
				_clock.restart();
			}
		}
	}
};