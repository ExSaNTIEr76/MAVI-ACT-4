//SANTIAGO EXEQUIEL FERN�NDEZ - MAVI ACT. 4:

#include "stdafx.h"
#include "PlayerCrosshair.h"
#include "Enemigo.h"

using namespace sf;

class Juego {

	RenderWindow* _wnd;
	PlayerCrosshair* _player;
	Enemigo* _enemigos;
	Text _puntaje;
	Font _fuente;
	int _puntos;

	void _actualizarPuntaje() {
		char pts[100];
		_itoa_s(_puntos, pts, 100, 10);
		_puntaje.setString(pts);
	}

public:

	Juego() {
		_wnd = new RenderWindow(VideoMode(800, 600), "Clickale");
		_player = new PlayerCrosshair();
		_enemigos = new Enemigo[5];
		_puntos = 0;

		_fuente.loadFromFile("arial.ttf");
		_puntaje.setFont(_fuente);
		_puntaje.setPosition(0.0f, 0.0f);
		_puntaje.setCharacterSize(50.0f);
		_puntaje.setFillColor(Color::Black);

		_actualizarPuntaje();
	}

	void Loop() {
		while (_wnd->isOpen()) {
			ProcesarEventos();
			Actualizar();
			Dibujar();
		}
	}

	void ProcesarEventos() {
		Event evt;
		while (_wnd->pollEvent(evt)) {
			switch (evt.type) {
			case Event::Closed:
				_wnd->close();
				break;
			case Event::MouseMoved:
				_player->Posicionar(evt.mouseMove.x, evt.mouseMove.y);
				break;
			case Event::MouseButtonPressed:
				if (evt.mouseButton.button == Mouse::Button::Left)
					Disparar();
				break;

			}
		}
	}

	void Actualizar() {
		for (size_t i = 0; i < 5; i++)
		{
			_enemigos[i].Actualizar(_wnd);
		}
	}

	void Disparar() {
		Vector2f playerPos = _player->ObtenerPosicion();
		for (int i = 0; i < 5; i++)
		{
			if (_enemigos[i].EstaActivo()) {
				if (_enemigos[i].EstaEncima(playerPos.x, playerPos.y))
					_enemigos[i].Derrotar();
				_puntos++;
			}
		}
		_actualizarPuntaje();
	}

	void Dibujar() {
		_wnd->clear(Color::White);

		for (int i = 0; i < 5; i++)
		{
			if (_enemigos[i].EstaActivo())
				_enemigos[i].Dibujar(_wnd);
		}

		_wnd->draw(_puntaje);
		_player->Dibujar(_wnd);
		_wnd->display();
	}

	~Juego() {
		delete[]_enemigos;
		delete _player;
		delete _wnd;
	}
};

int main() {

	Juego myJuego;
	myJuego.Loop();


	return 0;
};