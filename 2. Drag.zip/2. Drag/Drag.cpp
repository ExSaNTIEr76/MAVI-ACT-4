//SANTIAGO EXEQUIEL FERN�NDEZ - MAVI ACT. 4:

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

Texture texture1;
Texture texture2;
Texture texture3;
Texture texture4;
Texture texture5;

Sprite sprite1;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;
Sprite sprite5;

int main() {

	texture1.loadFromFile("rcircle.png");
	texture2.loadFromFile("rcircle.png");
	texture3.loadFromFile("rcircle.png");
	texture4.loadFromFile("rcircle.png");
	texture5.loadFromFile("rcircleb.png");

	sprite1.setTexture(texture1);
	sprite2.setTexture(texture2);
	sprite3.setTexture(texture3);
	sprite4.setTexture(texture4);
	sprite5.setTexture(texture5);

	sprite1.setPosition(0, 0);
	sprite2.setPosition(673, 0);
	sprite3.setPosition(0, 473);
	sprite4.setPosition(673, 473);
	sprite5.setPosition(335, 245);

	sf::RenderWindow App(sf::VideoMode(800, 600), "Drag");

    sf::Sprite* selectedSprite = nullptr;

    while (App.isOpen())
    {
        sf::Event event;
        while (App.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                App.close();
            }
            else if (event.type == sf::Event::MouseButtonPressed)
            {
                sf::Vector2i mousePosition = sf::Mouse::getPosition(App);
                sf::Vector2f worldPosition = App.mapPixelToCoords(mousePosition);

                if (sprite1.getGlobalBounds().contains(worldPosition))
                    selectedSprite = &sprite1;
                else if (sprite2.getGlobalBounds().contains(worldPosition))
                    selectedSprite = &sprite2;
                else if (sprite3.getGlobalBounds().contains(worldPosition))
                    selectedSprite = &sprite3;
                else if (sprite4.getGlobalBounds().contains(worldPosition))
                    selectedSprite = &sprite4;
                else if (sprite5.getGlobalBounds().contains(worldPosition))
                    selectedSprite = &sprite5;
            }
            else if (event.type == sf::Event::MouseButtonReleased)
            {
                selectedSprite = nullptr;
            }
        }

        if (selectedSprite)
        {
            sf::Vector2i mousePosition = sf::Mouse::getPosition(App);
            sf::Vector2f worldPosition = App.mapPixelToCoords(mousePosition);
            selectedSprite->setPosition(worldPosition);
        }

		App.clear();

		App.draw(sprite1);
		App.draw(sprite2);
		App.draw(sprite3);
		App.draw(sprite4);
		App.draw(sprite5);
		
		App.display();
	}
	return 0;
}