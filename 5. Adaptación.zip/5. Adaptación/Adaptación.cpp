//SANTIAGO EXEQUIEL FERN�NDEZ - MAVI ACT. 4:

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

int main() {
    VideoMode minVideoMode(100, 100);
    VideoMode maxVideoMode(1000, 1000);

    RenderWindow App(VideoMode(800, 600), "Adaptaci�n", Style::Default);

    while (App.isOpen()) {
        Event event;
        while (App.pollEvent(event)) {
            if (event.type == Event::Closed) {
                App.close();
            }
            else if (event.type == Event::Resized) {
                int newWidth = std::max(std::min(event.size.width, maxVideoMode.width), minVideoMode.width);
                int newHeight = std::max(std::min(event.size.height, maxVideoMode.height), minVideoMode.height);
                App.setSize(Vector2u(newWidth, newHeight));
            }
        }

        App.clear(Color::Black);
      
        App.display();
    }

    return 0;
}